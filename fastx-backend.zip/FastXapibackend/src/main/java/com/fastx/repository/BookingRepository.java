package com.fastx.repository;

import com.fastx.model.Booking;
import com.fastx.model.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findBySchedule(Schedule schedule);
    List<Booking> findByUserEmail(String email);
}
