package com.fastx.dto;

import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookingHistoryDTO {
    private Long id;
    private String busName;
    private int seatNumber;
    private LocalDate date;   
    private double amount;
    private String status;
}
