package com.fastx.exception;
import org.springframework.http.ResponseEntity;
public class GlobalExceptionHandler extends RuntimeException {

    public GlobalExceptionHandler(String message) {
        super(message);
    }
    public ResponseEntity<String> ResourceNotFoundException(String message) {
    	return ResponseEntity.internalServerError().body("An unexpected error occurred.");
    }
}
