package com.fastx.controller;

import com.fastx.model.Route;
import com.fastx.service.RouteService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/routes")
@SecurityRequirement(name = "bearerAuth")
@RequiredArgsConstructor
public class RouteController {

    private final RouteService routeService;

    // Only ADMIN can create routes
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<Route> createRoute(@RequestBody Route route) {
        return new ResponseEntity<>(routeService.createRoute(route), HttpStatus.CREATED);
    }

    // Both USER and ADMIN can view all routes
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public ResponseEntity<List<Route>> getAllRoutes() {
        return ResponseEntity.ok(routeService.getAllRoutes());
    }

    // Both USER and ADMIN can view a specific route
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<Route> getRouteById(@PathVariable Long id) {
        return ResponseEntity.ok(routeService.getRouteById(id));
    }

    // Only ADMIN can update routes
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<Route> updateRoute(@PathVariable Long id, @RequestBody Route route) {
        return ResponseEntity.ok(routeService.updateRoute(id, route));
    }

    // Only ADMIN can delete routes
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRoute(@PathVariable Long id) {
        routeService.deleteRoute(id);
        return ResponseEntity.noContent().build();
    }
}
