package com.fastx.controller;

import com.fastx.model.Booking;
import com.fastx.service.BookingService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/bookings")
@SecurityRequirement(name = "bearerAuth")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    @PostMapping("/{scheduleId}/book")
    public ResponseEntity<Booking> bookSeat(@PathVariable Long scheduleId, @RequestParam int seatNumber, Principal principal) {
        return ResponseEntity.ok(bookingService.bookSeat(scheduleId, seatNumber, principal));
    }

    
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    @GetMapping("/{scheduleId}/available-seats")
    public ResponseEntity<List<Integer>> getAvailableSeats(@PathVariable Long scheduleId) {
        return ResponseEntity.ok(bookingService.getAvailableSeats(scheduleId));
    }

    
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    @GetMapping("/my")
    public ResponseEntity<List<Booking>> getMyBookings(Principal principal) {
        return ResponseEntity.ok(bookingService.getUserBookings(principal.getName()));
    }

 
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/all")
    public ResponseEntity<List<Booking>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBooking(@PathVariable Long id) {
        boolean deleted = bookingService.deleteBookingById(id);
        if (deleted) {
            return ResponseEntity.ok("Booking deleted successfully");
        } else {
            return ResponseEntity.status(404).body("Booking not found");
        }
    }

}
