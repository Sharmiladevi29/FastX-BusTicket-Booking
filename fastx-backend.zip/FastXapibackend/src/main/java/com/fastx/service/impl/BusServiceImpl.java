package com.fastx.service.impl;

import com.fastx.model.Bus;
import com.fastx.repository.BusRepository;
import com.fastx.service.BusService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BusServiceImpl implements BusService {

    private final BusRepository busRepository;

    @Override
    public Bus addBus(Bus bus) {
        return busRepository.save(bus);
    }

    @Override
    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    @Override
    public Bus getBusById(Long id) {
        return busRepository.findById(id).orElseThrow(() -> new RuntimeException("Bus not found"));
    }

    @Override
    public void deleteBus(Long id) {
        busRepository.deleteById(id);
    }

    @Override
    public Bus updateBus(Long id, Bus updatedBus) {
        Bus existingBus = getBusById(id);
        existingBus.setBusName(updatedBus.getBusName());
        existingBus.setBusNumber(updatedBus.getBusNumber());
        existingBus.setBusType(updatedBus.getBusType());
        existingBus.setTotalSeats(updatedBus.getTotalSeats());
        existingBus.setFarePerSeat(updatedBus.getFarePerSeat());
        existingBus.setAmenities(updatedBus.getAmenities());
        return busRepository.save(existingBus);
    }
    @Override
    public List<Bus> search(String origin, String destination, String date) {
       
        return busRepository.findAll(); 
    }

}
