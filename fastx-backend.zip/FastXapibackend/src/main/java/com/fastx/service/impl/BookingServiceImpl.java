package com.fastx.service.impl;

import com.fastx.dto.BookingHistoryDTO;
import com.fastx.model.*;
import com.fastx.repository.*;
import com.fastx.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final ScheduleRepository scheduleRepository;
    private final UserRepository userRepository;

    @Override
    public Booking bookSeat(Long scheduleId, int seatNumber, Principal principal) {
        Schedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));

        List<Booking> existingBookings = bookingRepository.findBySchedule(schedule);
        Set<Integer> bookedSeats = existingBookings.stream()
                .map(Booking::getSeatNumber)
                .collect(Collectors.toSet());

        if (bookedSeats.contains(seatNumber)) {
            throw new RuntimeException("Seat already booked!");
        }

        User user = userRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Booking booking = Booking.builder()
                .user(user)
                .schedule(schedule)
                .seatNumber(seatNumber)
                .bookingTime(LocalDateTime.now())
                .build();

        return bookingRepository.save(booking);
    }

    @Override
    public List<Integer> getAvailableSeats(Long scheduleId) {
        Schedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));

        int totalSeats = schedule.getBus().getTotalSeats();
        List<Booking> booked = bookingRepository.findBySchedule(schedule);
        Set<Integer> bookedSeats = booked.stream().map(Booking::getSeatNumber).collect(Collectors.toSet());

        return IntStream.rangeClosed(1, totalSeats)
                .filter(seat -> !bookedSeats.contains(seat))
                .boxed()
                .collect(Collectors.toList());
    }

    @Override
    public List<Booking> getUserBookings(String email) {
        return bookingRepository.findByUserEmail(email);
    }
    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
    @Override
    public List<BookingHistoryDTO> getUserBookingHistory(String email) {
        List<Booking> bookings = bookingRepository.findByUserEmail(email);

        return bookings.stream().map(booking -> {
            BookingHistoryDTO dto = new BookingHistoryDTO();
            dto.setId(booking.getId());
            dto.setSeatNumber(booking.getSeatNumber());
            dto.setDate(booking.getSchedule().getJourneyDate());
            dto.setBusName(booking.getSchedule().getBus().getBusName());
            dto.setAmount(booking.getSchedule().getBus().getFarePerSeat());
            dto.setStatus("CONFIRMED"); 
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public boolean deleteBookingById(Long id) {
        if (bookingRepository.existsById(id)) {
            bookingRepository.deleteById(id);
            return true;
        }
        return false;
    }


}
