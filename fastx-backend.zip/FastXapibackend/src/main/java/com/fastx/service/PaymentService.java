package com.fastx.service;

import com.fastx.model.Payment;

import java.util.List;

public interface PaymentService {
    Payment makePayment(Payment payment);
    Payment getPaymentById(Long id);
    List<Payment> getAllPayments();
}
