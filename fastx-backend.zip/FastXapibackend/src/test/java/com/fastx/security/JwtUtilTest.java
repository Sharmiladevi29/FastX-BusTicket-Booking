package com.fastx.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;

public class JwtUtilTest {

    private JwtUtil jwtUtil;
    private final String testSecret = "fastx-super-secret-key-that-is-secure-and-long";

    @BeforeEach
    public void setUp() {
        jwtUtil = new JwtUtil();
        ReflectionTestUtils.setField(jwtUtil, "secret", testSecret);
    }

    @Test
    public void testGenerateTokenReturnsNonNull() {
        String token = jwtUtil.generateToken("test@example.com");
        assertNotNull(token, "Token should not be null");
    }

  
  

    @Test
    public void testInvalidTokenReturnsFalse() {
        String invalidToken = "malformed.token.value";
        assertFalse(jwtUtil.validateToken(invalidToken), "Invalid token should return false");
    }

    @Test
    public void testDifferentTokensForDifferentEmails() {
        String token1 = jwtUtil.generateToken("user1@fastx.com");
        String token2 = jwtUtil.generateToken("user2@fastx.com");
        assertNotEquals(token1, token2, "Tokens for different users should be different");
    }
}
