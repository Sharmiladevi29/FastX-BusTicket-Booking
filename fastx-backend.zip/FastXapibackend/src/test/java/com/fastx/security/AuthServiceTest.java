package com.fastx.security;

import com.fastx.dto.*;
import com.fastx.model.Role;
import com.fastx.model.User;
import com.fastx.repository.RoleRepository;
import com.fastx.repository.UserRepository;
import com.fastx.security.JwtUtil;
import com.fastx.service.AuthServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AuthServiceTest {

    @Mock private UserRepository userRepository;
    @Mock private RoleRepository roleRepository;
    @Mock private PasswordEncoder passwordEncoder;
    @Mock private JwtUtil jwtUtil;

    @InjectMocks
    private AuthServiceImpl authService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testRegisterNewUserReturnsSuccess() {
        RegisterRequest request = new RegisterRequest("Sharmi", "sharmi@gmail.com", "123", "Female", "9876543210", "Coimbatore");

        when(userRepository.existsByEmail(request.getEmail())).thenReturn(false);
        when(passwordEncoder.encode("123")).thenReturn("encodedPwd");
        when(roleRepository.findByName("USER")).thenReturn(Optional.of(new Role(1L, "USER")));
        when(jwtUtil.generateToken(request.getEmail())).thenReturn("mocked.jwt.token");

        AuthResponse response = authService.register(request);

        assertEquals("User registered successfully", response.getMessage());
        assertEquals("mocked.jwt.token", response.getToken());
        verify(userRepository).save(any(User.class));
    }

    @Test
    public void testRegisterFailsWhenEmailExists() {
        RegisterRequest request = new RegisterRequest("Sharmi", "sharmi@gmail.com", "123", "Female", "9876543210", "Coimbatore");

        when(userRepository.existsByEmail(request.getEmail())).thenReturn(true);

        AuthResponse response = authService.register(request);

        assertEquals("Email already registered", response.getMessage());
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    public void testLoginWithValidUserReturnsTokenAndRoleUser() {
        LoginRequest request = new LoginRequest("sharmi@gmail.com", "123");
        Role role = new Role(1L, "USER");
        User user = User.builder()
                .email(request.getEmail())
                .password("encodedPwd")
                .roles(Set.of(role))
                .build();

        when(userRepository.findByEmail(request.getEmail())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("123", "encodedPwd")).thenReturn(true);
        when(jwtUtil.generateToken(request.getEmail())).thenReturn("mocked.jwt.token");

        AuthResponse response = authService.login(request);

        assertEquals("mocked.jwt.token", response.getToken());
        assertEquals("USER", response.getRole());
        assertEquals("Login successful", response.getMessage());
    }

    @Test
    public void testLoginThrowsExceptionWhenPasswordWrong() {
        LoginRequest request = new LoginRequest("sharmi@gmail.com", "wrong");

        User user = User.builder()
                .email(request.getEmail())
                .password("encodedPwd")
                .roles(Set.of(new Role(1L, "USER")))
                .build();

        when(userRepository.findByEmail(request.getEmail())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("wrong", "encodedPwd")).thenReturn(false);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> authService.login(request));
        assertEquals("Invalid email or password", exception.getMessage());
    }

    @Test
    public void testLoginWithAdminRoleReturnsAdmin() {
        LoginRequest request = new LoginRequest("admin@fastx.com", "admin123");

        User user = User.builder()
                .email(request.getEmail())
                .password("encodedAdminPwd")
                .roles(Set.of(new Role(1L, "ADMIN")))
                .build();

        when(userRepository.findByEmail(request.getEmail())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("admin123", "encodedAdminPwd")).thenReturn(true);
        when(jwtUtil.generateToken(request.getEmail())).thenReturn("mocked.jwt.token");

        AuthResponse response = authService.login(request);

        assertEquals("ADMIN", response.getRole());
        assertEquals("Login successful", response.getMessage());
    }
}
