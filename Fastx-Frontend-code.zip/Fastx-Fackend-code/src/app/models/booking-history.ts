export interface BookingHistory {
  id: number;
  busName: string;
  seatNumber: number;
  date: string;
  amount: number;
  status: string;
}
