export interface Bus {
  id: number;
  busName: string;             
  busNumber: string;
  busType: string;
  totalSeats: number;
  farePerSeat: number;
  amenities: string;
}
