import { Bus } from './bus';

export interface Schedule {
  id: number;
  origin: string;
  destination: string;
  journeyDate: string;
  departureTime: {
    hour: number;
    minute: number;
  };
  arrivalTime: {
    hour: number;
    minute: number;
  };
  bus: Bus;
}
