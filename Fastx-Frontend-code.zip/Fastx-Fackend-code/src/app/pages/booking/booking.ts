import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.html',
  styleUrls: ['./booking.css'],
  standalone: false,
})
export class Booking {
  bus: any;
  seats: any[] = [];
  selectedSeats: any[] = [];
  total: number = 0;
  scheduleId: number = 1;
  lastBookingInfo: any = null;

  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router) {
    this.bus = {
      name: 'FastX Express',
      fare: 450
    };

    for (let i = 1; i <= 36; i++) {
      this.seats.push({
        number: i,
        booked: [2, 7, 12].includes(i),
        selected: false
      });
    }

    this.route.queryParams.subscribe(params => {
      if (params['scheduleId']) {
        this.scheduleId = +params['scheduleId'];
      }
    });
  }

  toggleSeat(seat: any) {
    if (seat.booked) return;

    seat.selected = !seat.selected;
    this.selectedSeats = this.seats.filter(s => s.selected);
    this.total = this.selectedSeats.length * this.bus.fare;
  }

  getSelectedSeatNumbers(): string {
    return this.selectedSeats.map(s => s.number).join(', ');
  }

  bookSeats() {
    const selected = this.selectedSeats.map(s => s.number);
    if (selected.length === 0) {
      alert('❗ Please select at least one seat.');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      alert('❗ You must be logged in to book seats.');
      return;
    }

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    let successCount = 0;

    selected.forEach(seatNumber => {
      this.http.post(`http://localhost:9090/api/bookings/${this.scheduleId}/book`, null, {
        headers,
        params: { seatNumber }
      }).subscribe({
        next: () => {
          const seat = this.seats.find(s => s.number === seatNumber);
          if (seat) {
            seat.booked = true;
            seat.selected = false;
          }

          successCount++;
          if (successCount === selected.length) {
            alert(`✅ Booking Confirmed!\nSeats: ${selected.join(', ')}\nTotal: ₹${this.total}`);

            // Fake booking info for demonstration (replace with real response later)
            const userId = 1; // Replace with actual user ID
            const bookingId = Math.floor(Math.random() * 10000); // Replace with actual booking ID
            this.storeBookingInfo(userId, bookingId, this.total);

            this.selectedSeats = [];
            this.total = 0;
          }
        },
        error: err => {
          console.error('❌ Booking failed for seat:', seatNumber, err);
          alert(`Booking failed for seat ${seatNumber}`);
        }
      });
    });
  }

  storeBookingInfo(userId: number, bookingId: number, amount: number) {
    this.lastBookingInfo = { userId, bookingId, amount };
  }

  proceedToPayment() {
    if (this.lastBookingInfo) {
      const { userId, bookingId, amount } = this.lastBookingInfo;
      this.router.navigate(['/payment'], {
        queryParams: { userId, bookingId, amount }
      });
    } else {
      alert("❗ No booking info found. Please book seats first.");
    }
  }
}
