import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.html',
  styleUrls: ['./profile.css'],
  standalone: false
})
export class Profile implements OnInit {
  bookings: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.get<any[]>('http://localhost:9090/api/bookings/my', { headers })
      .subscribe({
        next: (data) => {
          console.log('USER BOOKINGS:', data);
          this.bookings = data;
        },
        error: (err) => {
          console.error('BOOKINGS FETCH ERROR:', err);
          alert('Could not load your bookings.');
        }
      });
  }
}
