import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Schedule } from '../../models/schedule';
import { ScheduleService } from '../../services/schedule';

@Component({
  selector: 'app-search',
  templateUrl: './search.html',
  styleUrls: ['./search.css'],
  standalone: false,
})
export class Search {
  searchForm: FormGroup;
  schedules: Schedule[] = [];

  constructor(private fb: FormBuilder, private scheduleService: ScheduleService) {
    this.searchForm = this.fb.group({
      origin: [''],
      destination: [''],
      date: ['']
    });
  }

 onSearch() {
  const { origin, destination, date } = this.searchForm.value;

  const formattedDateTime = this.formatDateTime(date); // Format it correctly

  this.scheduleService.searchSchedules(origin, destination, formattedDateTime).subscribe({
    next: (response: Schedule[]) => {
      this.schedules = response;
    },
    error: (error) => {
      this.schedules = [];
      console.error('Schedule fetch error:', error);
      alert('Something went wrong while fetching schedules.');
    }
  });
}

private formatDateTime(dateTime: string): string {
  return dateTime.includes(':') ? `${dateTime}:00` : dateTime;
}

}
