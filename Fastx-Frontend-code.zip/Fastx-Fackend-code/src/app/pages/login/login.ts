import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-login',
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
  standalone: false,
})
export class Login {
  loginForm: FormGroup;
  message: string = '';
  success: boolean = false;

  constructor(private fb: FormBuilder, private auth: Auth, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onLogin() {
  if (this.loginForm.valid) {
    this.auth.login(this.loginForm.value).subscribe({
      next: (res: any) => {
       console.log('Login Response:', res);
console.log('Role received from backend:', res.role);


        localStorage.setItem('token', res.token);
        localStorage.setItem('email', res.email);
        localStorage.setItem('role', res.role);

        this.success = true;
        this.message = 'Login successful!';

        setTimeout(() => {
          const role = res.role?.toUpperCase();
          console.log('Role:', role);

          if (role === 'ADMIN') {
            this.router.navigateByUrl('/admin-dashboard'); 
          } else {
            this.router.navigateByUrl('/user-dashboard');
          }
        }, 1000);
      },
      error: () => {
        this.success = false;
        this.message = 'Invalid email or password.';
      }
    });
  }
}


}
