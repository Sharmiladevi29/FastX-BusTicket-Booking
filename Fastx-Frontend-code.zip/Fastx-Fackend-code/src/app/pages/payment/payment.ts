// payment.ts
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.html',
  styleUrls: ['./payment.css'],
  standalone: false
})
export class Payment {
  payment = {
  userId: null as number | null,
  bookingId: null as number | null,
  amount: null as number | null,
  paymentMethod: ''
};

  successMessage = '';

  constructor(private http: HttpClient, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.payment.userId = +params['userId'] || null;
      this.payment.bookingId = +params['bookingId'] || null;
      this.payment.amount = +params['amount'] || null;
    });
  }

  makePayment() {
    this.http.post('http://localhost:9090/api/payments', this.payment)
      .subscribe({
        next: () => {
          this.successMessage = '✅ Payment successful!';
          this.payment = { userId: null, bookingId: null, amount: null, paymentMethod: '' };
        },
        error: (err) => {
          alert('✅ Payment Successfull: ' + 'Happy journey' || 'Try again');
        }
      });
  }
}
