import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css'],
  standalone: false
})
export class AdminDashboard implements OnInit {
  buses: any[] = [];
  schedules: any[] = [];
  bookings: any[] = [];
  editId: number | null = null;

  newBus = {
    busName: '',
    busType: '',
    farePerSeat: 0
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadBuses();
    this.loadSchedules();
    this.loadBookings();
  }

  get headers() {
    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${localStorage.getItem('token')}`
      })
    };
  }

  loadBuses() {
    this.http.get<any[]>('http://localhost:9090/api/buses', this.headers).subscribe({
      next: (data) => this.buses = data,
      error: (err) => alert('❌ Error loading buses')
    });
  }

  loadSchedules() {
    this.http.get<any[]>('http://localhost:9090/api/schedules', this.headers).subscribe({
      next: (data) => this.schedules = data,
      error: (err) => alert('❌ Error loading schedules')
    });
  }

  loadBookings() {
    this.http.get<any[]>('http://localhost:9090/api/bookings/all', this.headers).subscribe({
      next: (data) => this.bookings = data,
      error: (err) => alert('❌ Error loading bookings')
    });
  }

  addBus() {
    if (!this.newBus.busName || !this.newBus.busType || this.newBus.farePerSeat <= 0) {
      alert('Please fill all fields correctly.');
      return;
    }

    this.http.post('http://localhost:9090/api/buses', this.newBus, this.headers).subscribe({
      next: () => {
        alert('✅ Bus added!');
        this.newBus = { busName: '', busType: '', farePerSeat: 0 };
        this.loadBuses();
      },
      error: () => alert('❌ Failed to add bus')
    });
  }

  updateBus(bus: any) {
    this.http.put(`http://localhost:9090/api/buses/${bus.id}`, bus, this.headers).subscribe({
      next: () => {
        alert('✅ Bus updated!');
        this.editId = null;
        this.loadBuses();
      },
      error: () => alert('❌ Failed to update bus')
    });
  }
updateSchedule(schedule: any) {
  this.http.put(`http://localhost:9090/api/schedules/${schedule.id}`, schedule, this.headers).subscribe({
    next: () => {
      alert('✅ Schedule updated!');
      this.loadSchedules();
    },
    error: () => alert('❌ Failed to update schedule')
  });
}

deleteSchedule(id: number) {
  if (confirm('Are you sure you want to delete this schedule?')) {
    this.http.delete(`http://localhost:9090/api/schedules/${id}`, this.headers).subscribe({
      next: () => {
        alert('🗑️ Schedule deleted!');
        this.loadSchedules();
      },
      error: () => alert('❌ Failed to delete schedule')
    });
  }
}

deleteBooking(id: number) {
  if (confirm('Are you sure you want to delete this booking?')) {
    this.http.delete(`http://localhost:9090/api/bookings/${id}`, this.headers).subscribe({
      next: () => {
        alert('🗑️ Booking deleted!');
        this.loadBookings();
      },
      error: () => alert('❌ Failed to delete booking')
    });
  }
}

  deleteBus(id: number) {
    if (confirm('Are you sure you want to delete this bus?')) {
      this.http.delete(`http://localhost:9090/api/buses/${id}`, this.headers).subscribe({
        next: () => {
          alert('🗑️ Bus deleted!');
          this.loadBuses();
        },
        error: () => alert('❌ Failed to delete bus')
      });
    }
  }
  
}
