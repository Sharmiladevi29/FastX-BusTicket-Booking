import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-register',
  templateUrl: './register.html',
  styleUrls: ['./register.css'],
  standalone: false
})
export class Register {
  registerForm: FormGroup;
  message: string = '';

  constructor(private fb: FormBuilder, private auth: Auth) {
    this.registerForm = this.fb.group({
  name: ['', Validators.required],
  email: ['', [Validators.required, Validators.email]],
  password: ['', [Validators.required, Validators.minLength(6)]],
  gender: ['', Validators.required],
  contactNumber: ['', Validators.required],
  address: ['', Validators.required]
});

  }

 onRegister() {
  if (this.registerForm.valid) {
    console.log('📦 Form Data:', this.registerForm.value);

    this.auth.register(this.registerForm.value).subscribe({
      next: () => {
        this.message = 'Registration successful! Please login.';
      },
      error: (err) => {
        console.error('Registration failed:', err);
        this.message = err?.error?.message || 'Registration failed. Try again.';
      }
    });
  }
}

}
