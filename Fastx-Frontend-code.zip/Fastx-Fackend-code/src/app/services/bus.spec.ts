import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BusService } from './bus';
import { Bus } from '../models/bus';

describe('BusService', () => {
  let service: BusService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BusService]
    });

    service = TestBed.inject(BusService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // ensures no outstanding requests
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch buses based on origin, destination and date', () => {
    const dummyBuses: Bus[] = [
      {
        id: 1,
        name: 'FastX AC',
        type: 'Sleeper AC',
        time: '10:00 AM',
        fare: 500,
        origin: 'Chennai',
        destination: 'Madurai',
        date: '2025-07-06',
        totalSeats: 40,
        availableSeats: 20,
        amenities: ['WiFi', 'Charging Point']
      }
    ];

    service.searchBuses('Chennai', 'Madurai', '2025-07-06').subscribe((buses) => {
      expect(buses.length).toBe(1);
      expect(buses).toEqual(dummyBuses);
    });

    const req = httpMock.expectOne(
      'http://localhost:8080/api/bus/search?origin=Chennai&destination=Madurai&date=2025-07-06'
    );
    expect(req.request.method).toBe('GET');
    req.flush(dummyBuses); // simulate response
  });
});
