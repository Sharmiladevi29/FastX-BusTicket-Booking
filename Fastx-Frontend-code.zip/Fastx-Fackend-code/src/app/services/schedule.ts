import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Schedule } from '../models/schedule';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {
  private baseUrl = 'http://localhost:9090/api/schedules';

  constructor(private http: HttpClient) {}

  searchSchedules(origin: string, destination: string, date: string): Observable<Schedule[]> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    return this.http.get<Schedule[]>(
      `${this.baseUrl}/search?origin=${origin}&destination=${destination}&date=${date}`,
      { headers }
    );
  }
}
