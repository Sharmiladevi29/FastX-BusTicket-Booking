import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Bus } from '../models/bus';

@Injectable({
  providedIn: 'root'
})
export class BusService {
  private baseUrl = 'http://localhost:9090/api/buses'; // update if different

  constructor(private http: HttpClient) {}

  searchBuses(origin: string, destination: string, date: string): Observable<Bus[]> {
    return this.http.get<Bus[]>(`${this.baseUrl}/search?origin=${origin}&destination=${destination}&date=${date}`);
  }
}
export type { Bus }; 


