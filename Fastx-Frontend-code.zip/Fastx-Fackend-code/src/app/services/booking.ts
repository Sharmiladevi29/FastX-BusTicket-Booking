import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BookingHistory } from '../models/booking-history';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private baseUrl = 'http://localhost:9090/api/bookings';

  constructor(private http: HttpClient) {}

  // ✅ Get logged-in user's bookings using JWT token
  getUserBookings(): Observable<BookingHistory[]> {
    const token = localStorage.getItem('token');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    return this.http.get<BookingHistory[]>(`${this.baseUrl}/my`, { headers });
  }
}
