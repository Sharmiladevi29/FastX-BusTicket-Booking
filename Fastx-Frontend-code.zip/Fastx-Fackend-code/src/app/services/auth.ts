import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Auth {
 private baseUrl = 'http://localhost:9090/api/auth';


  constructor(private http: HttpClient) {}

  register(user: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, user);
  }

login(credentials: any): Observable<any> {
  return this.http.post<any>(`${this.baseUrl}/login`, credentials).pipe(
    tap((res) => {
      localStorage.setItem('token', res.token);
      localStorage.setItem('email', res.email);
      localStorage.setItem('role', res.role); 
    })
  );
}

  
}
