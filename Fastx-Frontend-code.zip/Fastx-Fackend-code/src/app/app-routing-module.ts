import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './pages/home/home';
import { Login } from './pages/login/login';
import { Register } from './pages/register/register';
import { Search } from './pages/search/search';
import { Booking } from './pages/booking/booking';
import { Profile } from './pages/profile/profile';
import { AdminDashboard } from './pages/admin-dashboard/admin-dashboard';
import { UserDashboard } from './pages/user-dashboard/user-dashboard';
import { About } from './pages/about/about';
import { Review } from './components/review/review';
import { Payment } from './pages/payment/payment';

const routes: Routes = [
  {path:'',component:Home},
  { path: 'home', component: Home },
  { path: 'about', component: About },
  {path:'login',component:Login},
  {path:'register',component:Register},
  {path:'search',component:Search},
  {path:'booking',component:Booking},
  {path:'profile',component:Profile},
  { path: 'review', component: Review },
  {path:'payment',component:Payment},
  {path:'admin-dashboard',component:AdminDashboard},
  {path:'user-dashboard',component:UserDashboard}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
