import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Navbar } from './components/navbar/navbar';
import { Login } from './pages/login/login';
import { Register } from './pages/register/register';
import { Home } from './pages/home/home';
import { Search } from './pages/search/search';
import { Booking } from './pages/booking/booking';
import { Profile } from './pages/profile/profile';
import { AdminDashboard } from './pages/admin-dashboard/admin-dashboard';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ScheduleService } from './services/schedule';
import { UserDashboard } from './pages/user-dashboard/user-dashboard';
import { About } from './pages/about/about';
import { Review } from './components/review/review';
import { Payment } from './pages/payment/payment';

@NgModule({
  declarations: [
    App,
    Navbar,
    Login,
    Register,
    Home,
    Search,
    Booking,
    Profile,
    AdminDashboard,
    UserDashboard,
    About,
    Review,
    Payment
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    AppRoutingModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
    ScheduleService
  ],
  bootstrap: [App]
})
export class AppModule { }
